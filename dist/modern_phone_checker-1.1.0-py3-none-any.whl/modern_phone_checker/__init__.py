"""Modern Phone Checker - A modern and ethical phone number verification tool"""

from .core import PhoneChecker
from .models import PhoneCheckResult

__version__ = '0.1.0'
